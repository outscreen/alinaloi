#include <windows.h>
#include  <stdio.h>
#include  <commctrl.h>

   const IDN_copy=100;
   const IDN_name=101;
   const IDN_separator=102;
   const IDN_exit=103;
   const IDN_list=200;
   const ID_but1=301;
   const ID_but2=302;
   const ID_but3=303;
   const ID_but4=304;
   const ID_but5=305;
   const ID_list=307;
   const ID_edit1=308;
   const ID_edit2=309;
   const ID_edit3=310;

HINSTANCE hInst;
LRESULT CALLBACK   WndProc(HWND,UINT,UINT,LONG);  
HMENU hMenu,hFileMenu;


void put(char cBack[2000],char cNext[2000])
{
int	i=0;
int j=0;

   if(cNext[2]=='a'&&cNext[3]=='-')
			{
cNext[0]='a';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='b'&&cNext[3]=='-')
			{
cNext[0]='b';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='c'&&cNext[3]=='-')
			{
cNext[0]='c';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='d'&&cNext[3]=='-')
			{
cNext[0]='d';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='e'&&cNext[3]=='-')
			{
cNext[0]='e';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='f'&&cNext[3]=='-')
			{
cNext[0]='f';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='g'&&cNext[3]=='-')
			{
cNext[0]='g';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='h'&&cNext[3]=='-')
			{
cNext[0]='h';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='i'&&cNext[3]=='-')
			{
cNext[0]='i';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='j'&&cNext[3]=='-')
			{
cNext[0]='j';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='k'&&cNext[3]=='-')
			{
cNext[0]='k';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='l'&&cNext[3]=='-')
			{
cNext[0]='l';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='m'&&cNext[3]=='-')
			{
cNext[0]='m';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='n'&&cNext[3]=='-')
			{
cNext[0]='n';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='o'&&cNext[3]=='-')
			{
cNext[0]='o';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='p'&&cNext[3]=='-')
			{
cNext[0]='p';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='q'&&cNext[3]=='-')
			{
cNext[0]='q';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='r'&&cNext[3]=='-')
			{
cNext[0]='r';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='s'&&cNext[3]=='-')
			{
cNext[0]='s';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='t'&&cNext[3]=='-')
			{
cNext[0]='t';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='u'&&cNext[3]=='-')
			{
cNext[0]='u';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='v'&&cNext[3]=='-')
			{
cNext[0]='v';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='w'&&cNext[3]=='-')
			{
cNext[0]='w';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='x'&&cNext[3]=='-')
			{
cNext[0]='x';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='y'&&cNext[3]=='-')
			{
cNext[0]='y';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	if(cNext[2]=='z'&&cNext[3]=='-')
			{
cNext[0]='z';
cNext[1]=':';
cNext[2]='\0';
			}
			else
	while(cNext[i]!=']')
	{
	 if(cNext[i+1]!=']')
	 {
       cNext[i]=cNext[i+1];
       cNext[i+1]='\0';
	 }
      i++;
	}
	while (cBack[j]!='\0') j++;
	if(j!=0) j=j-3;
i=0;
    while(cNext[i]!='\0')
	 {
       cBack[j]=cNext[i];
       j++;
       i++;
	 }

cBack[j]='\\';
cBack[j+1]='*';
cBack[j+2]='.';
cBack[j+3]='*';
cBack[j+4]='\0';

}


int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{    

    HWND hWnd; 
	MSG msg;
    WNDCLASS wcex;

	
hInst=hInstance;

	wcex.style			= CS_HREDRAW|CS_VREDRAW ;	
	wcex.lpfnWndProc	= (WNDPROC)WndProc; 
	wcex.cbClsExtra		= 0;						
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;	
	wcex.hIcon			= LoadIcon(NULL,IDI_APPLICATION);		
	wcex.hCursor		= LoadCursor(NULL,IDC_ARROW ); 
	wcex.hbrBackground	= (HBRUSH)GetStockObject (LTGRAY_BRUSH );
	wcex.lpszMenuName	=  NULL;
	wcex.lpszClassName	= "MyKlass";

	RegisterClass(&wcex);

hWnd=CreateWindow("MyKlass",
                  "�������� ������ [���������]", 
                   WS_OVERLAPPED|WS_SYSMENU|WS_MINIMIZEBOX,
                   CW_USEDEFAULT,
                   CW_USEDEFAULT,
                   600,450,NULL,NULL,       
                   hInstance,NULL);



AppendMenu((hFileMenu=CreatePopupMenu()),
		   MF_GRAYED|MF_STRING,
           IDN_copy,"&Copy File");

AppendMenu(hFileMenu,MF_GRAYED|MF_STRING,IDN_name,"Rename");
AppendMenu(hFileMenu,MF_SEPARATOR,IDN_separator,"MF_OWNERDRAW");
AppendMenu(hFileMenu,MF_ENABLED|MF_STRING,IDN_exit,"Exit");

hMenu=CreateMenu();

AppendMenu(hMenu,MF_ENABLED|MF_POPUP,(UINT)hFileMenu,"&File");

SetMenu(hWnd,hMenu);


   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);
   DrawMenuBar(hWnd);

 	while (GetMessage(&msg, NULL, 0, 0)) 
	{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
	}
	return msg.wParam;
}

 


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{


 
	static char cNext[2000],cBack[2000],editT[2000],eT2[2000],eT3[2000],ist[1000][2000];
	static HWND hList,hButton1,hButton2,hButton3,hButton4,hButton5,hEdit1,hEdit2,hEdit3;
    static int i=0;
    int j,k;



	switch (message) 
	{  
		case WM_CREATE:

hList=CreateWindow("LISTBOX","",LBS_NOTIFY|WS_VSCROLL|WS_BORDER|WS_CHILD|WS_VISIBLE|
		            WS_TABSTOP|LBS_DISABLENOSCROLL,
				    0,22,305,390,
				    hWnd,(HMENU)ID_list,hInst,NULL);

SendMessage(hList,LB_DIR,(WPARAM)DDL_DRIVES|DDL_DIRECTORY,(LPARAM)"");
	
hButton2= CreateWindow("BUTTON", "Exit",WS_VISIBLE |WS_CHILD|
	                       BS_PUSHBUTTON, 510, 22, 80, 40,
                           hWnd,(HMENU)ID_but2,hInst, NULL);

hEdit1= CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|WS_BORDER|
		                   ES_LEFT|ES_NOHIDESEL|ES_READONLY,
						   0,0,593,20,hWnd,(HMENU)ID_edit1,
						   hInst,NULL);

SendMessage(hEdit1,EM_REPLACESEL,0,(LPARAM)"��� ���������");
i=0;
cBack[0]='\0';
    	break;

        case WM_COMMAND:
		               if (HIWORD(wParam)==LBN_DBLCLK)
					   {
						   
			        	    SendMessage(hList,LB_GETTEXT,SendMessage(hList,
				                        LB_GETCURSEL,0,0),(LPARAM)cNext);
						    if(cNext[0]=='[')
						        if(cNext[0]=='[' &&cNext[2]=='.'&&cNext[1]=='.')
								   SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but1),0);
						        else
								{				
                                   
                                   put(cBack,cNext);
						           i++;
                                   j=0;
						           while(cBack[j]!='\0')
								   {

							        ist[i][j]=cBack[j];
							        j++;
								   }
						            ist[i][j]='\0';
						            
						            while(SendMessage(hList,LB_DELETESTRING,0,0)!=0);
					
                                    DWORD dwPos=SendMessage(hEdit1,EM_GETSEL,0,0);
                                    SendMessage(hEdit1,EM_SETSEL,0,MAKELONG(LOWORD(dwPos),HIWORD(dwPos)));
                                    SendMessage(hEdit1,EM_REPLACESEL,0,(LPARAM)cBack);	
                                    SendMessage(hList,LB_DIR,(WPARAM)DDL_DIRECTORY,(LPARAM)cBack);
									if(SendMessage(hList,LB_GETCOUNT,0,0)==0&&cBack[3]=='*')
									{
										j=IDYES;
									while( SendMessage(hList,LB_GETCOUNT,0,0)==0&&j==IDYES)
									{	
									    j=MessageBox(NULL,"���������� �� ������ ��� ���� �� �������� ����������. ���������?","",
									                 MB_YESNO|MB_ICONEXCLAMATION);
                                        if(j!=IDNO)SendMessage(hList,LB_DIR,(WPARAM)DDL_DIRECTORY,(LPARAM)cBack);
									}
									if(j==IDNO)
                                       SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but1),0);
									}
                                    if(i==1)hButton1= CreateWindow("BUTTON", "Up to level",WS_VISIBLE |WS_CHILD|
	                                                               BS_PUSHBUTTON, 310, 22, 200, 40,
                                                                   hWnd,(HMENU)ID_but1,hInst, NULL);
           						}
					   }

			           switch(LOWORD(wParam))
					   {
		    	         case IDN_exit:
                         case ID_but2:  
				              SendMessage(hWnd,WM_DESTROY,NULL,NULL);
				         break;
     			
				         case IDN_copy:
							 {
                              SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but4),0);

                              hEdit2= CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|ES_MULTILINE|
		                                            ES_LEFT|ES_NOHIDESEL|ES_READONLY,
						                            310,80,280,36,hWnd,(HMENU)ID_edit2,
						                            hInst,NULL);

                              hButton3= CreateWindow("BUTTON", "OK",WS_VISIBLE |WS_CHILD|
	                                                  BS_PUSHBUTTON, 350,160,70,30,
                                                      hWnd,(HMENU)ID_but3,hInst, NULL);

                              hButton4= CreateWindow("BUTTON", "Cencel",WS_VISIBLE |WS_CHILD|
	                                                  BS_PUSHBUTTON, 465,160,70,30,
                                                      hWnd,(HMENU)ID_but4,hInst, NULL);

					          SendMessage(hEdit2,EM_REPLACESEL,0,
								          (LPARAM)"������� ����,���� ������� ����������� ����");

                              hEdit3= CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|WS_BORDER|
		                                            ES_LEFT|ES_NOHIDESEL|ES_AUTOHSCROLL,
						                            310,116,280,20,hWnd,(HMENU)ID_edit3,
						                            hInst,NULL);

                              j=0;
	                          while(cBack[j]!='*') 
							  {
                        		  editT[j]=cBack[j];
		                          j++;
							  }
	                          editT[j]='\0';
                           	  
							  SendMessage(hEdit3,EM_REPLACESEL,0,(LPARAM)editT);

 
							 }
                         break;
				         case IDN_name:
							 {
                              SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but4),0);

                              hEdit2= CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|ES_MULTILINE|
		                                            ES_LEFT|ES_NOHIDESEL|ES_READONLY,
						                            310,80,280,36,hWnd,(HMENU)ID_edit2,
						                            hInst,NULL);

                              hButton5= CreateWindow("BUTTON", "OK",WS_VISIBLE |WS_CHILD|
	                                                  BS_PUSHBUTTON, 350,160,70,30,
                                                      hWnd,(HMENU)ID_but5,hInst, NULL);

                              hButton4= CreateWindow("BUTTON", "Cencel",WS_VISIBLE |WS_CHILD|
	                                                  BS_PUSHBUTTON, 465,160,70,30,
                                                      hWnd,(HMENU)ID_but4,hInst, NULL);

                              SendMessage(hEdit2,EM_REPLACESEL,0,(LPARAM)"������� ����� ��� �����");
					
					          hEdit3= CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|WS_BORDER|
		                                            ES_LEFT|ES_NOHIDESEL|ES_AUTOHSCROLL,
						                            310,116,280,20,hWnd,(HMENU)ID_edit3,
						                            hInst,NULL);
 
                              j=0;
                        	  while(cNext[j]!='\0') 
							  {
		                        editT[j]=cNext[j];
		                        j++;
							  }
	                          editT[j]='\0';

	                          SendMessage(hEdit3,EM_REPLACESEL,0,(LPARAM)editT);
					
							 }
				         break;

				         case ID_list:
					          if (HIWORD(wParam)==LBN_SELCHANGE)
							  {
 	                              SendMessage(hList,LB_GETTEXT,SendMessage(hList,
				                              LB_GETCURSEL,0,0),(LPARAM)cNext);

                                  SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but4),0);

                                  if(cNext[0]!='[')
								  {
                            		EnableMenuItem(hFileMenu,IDN_name,MF_ENABLED);
                                  	EnableMenuItem(hFileMenu,IDN_copy,MF_ENABLED);
								  }
	                              else
								  {
                              		EnableMenuItem(hFileMenu,IDN_name,MF_GRAYED);
	                                EnableMenuItem(hFileMenu,IDN_copy,MF_GRAYED);
								  }
							  }
                         break;

				         case ID_but1:
                              EnableMenuItem(hFileMenu,IDN_name,MF_GRAYED);
	                          EnableMenuItem(hFileMenu,IDN_copy,MF_GRAYED);
           					  i--;
					          if(i==0)
							  {
						     
								if(SendMessage(hList,LB_GETCOUNT,0,0)!=0)
                                   while(SendMessage(hList,LB_DELETESTRING,0,0)!=0);

                                DWORD dwPos=SendMessage(hEdit1,EM_GETSEL,0,0);
                                SendMessage(hEdit1,EM_SETSEL,0,MAKELONG(LOWORD(dwPos),HIWORD(dwPos)));
                                SendMessage(hEdit1,EM_REPLACESEL,0,(LPARAM)"��� ���������");
                            
                                SendMessage(hList,LB_DIR,(WPARAM)DDL_DRIVES,(LPARAM)"");
                                cBack[0]='\0';

                                SendMessage(hButton1,WM_CLOSE,0,0);
							  }
					          else
							  { 
						        j=0;
						        while(ist[i][j]!='\0')
								{
							      cBack[j]=ist[i][j];
							      j++;
								}
						        cBack[j]='\0';
			                    while(SendMessage(hList,LB_DELETESTRING,0,0)!=0);

                                DWORD dwPos=SendMessage(hEdit1,EM_GETSEL,0,0);
                                SendMessage(hEdit1,EM_SETSEL,0,MAKELONG(LOWORD(dwPos),HIWORD(dwPos)));
                                SendMessage(hEdit1,EM_REPLACESEL,0,(LPARAM)cBack);

                                SendMessage(hList,LB_DIR,(WPARAM)DDL_DIRECTORY,(LPARAM)cBack);
							  }
       	       		     break;

				         case ID_but3:
                              SendMessage(hEdit3,EM_GETLINE,(WPARAM)1,(LPARAM)editT);
                              k=j=0;
                              while(editT[j]!='\0')j++;
							  if((editT[j]=='\0')&&(editT[j-1]=='\\'))
                              while(cNext[k]!='\0')
							  {
                              	editT[j]=cNext[k];
	                            j++;
	                            k++;
							  }
                              editT[j]='\0';
                              k=j=0;
                              while(cBack[j]!='*')
							  {
	                            eT2[j]=cBack[j];
	                            j++;
							  }
                              while(cNext[k]!='\0')
							  {
	                            eT2[j]=cNext[k];
	                            j++;
	                            k++;
							  }
                              eT2[j]='\0';
                              if(!CopyFile(eT2,editT,TRUE))
                                 if(GetLastError()==3)
									 MessageBox(NULL,"���������� ������ ������ �� ����������",
                                                 "Error",MB_OK|MB_ICONERROR);
								 else
                                 if(GetLastError()==5)
									 MessageBox(NULL,"     ��������� ������ ��� ����������� ����� !\n���� ����� ���� ���������� ��� ������� �� ������",
                                                 "Error",MB_OK|MB_ICONERROR);
                                  else
                                      if((GetLastError()==80)&&(MessageBox(NULL,"���� ��� ����������. �������� ��� ?",
                                                               "������������ ������ �����",
															    MB_YESNO|MB_ICONQUESTION)==IDYES))
	                                      CopyFile(eT2,editT,FALSE);
							  
                               SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but4),0);
    					 break;

				         case ID_but4:
                              SendMessage(hButton3,WM_CLOSE,0,0);
                              SendMessage(hButton4,WM_CLOSE,0,0);
                              SendMessage(hButton5,WM_CLOSE,0,0);
                              SendMessage(hEdit2,WM_CLOSE,0,0);
                              SendMessage(hEdit3,WM_CLOSE,0,0);
        			     break;

				         case ID_but5:
                              k=j=0;
                              while(cBack[j]!='*')
							  {
                              	eT2[j]=cBack[j];
	                            j++;
							  }
                              while(cNext[k]!='\0')
							  {
	                             eT2[j]=cNext[k];
	                             j++;
	                             k++;
							  }
                              eT2[j]='\0';
                              SendMessage(hEdit3,EM_GETLINE,(WPARAM)1,(LPARAM)editT);
                              k=j=0;
                              while(cBack[j]!='*')
							  {
	                             eT3[j]=cBack[j];
	                             j++;
							  }
                              while(editT[k]!='\0')
							  {
	                             eT3[j]=editT[k];
	                             j++;
	                             k++;
							  }
                              eT3[j]='\0';
                              if(!MoveFile(eT2,eT3))
                                 MessageBox(NULL,"��������� ������ ��� �������������� ����� ! \n���� ����� ���� ������� �� ������",
								             "Error",MB_OK|MB_ICONERROR);
                              
			                  while(SendMessage(hList,LB_DELETESTRING,0,0)!=0);
                              SendMessage(hList,LB_DIR,(WPARAM)DDL_DIRECTORY,(LPARAM)cBack);
                              SendMessage(hWnd,WM_COMMAND,(WPARAM)LOWORD(ID_but4),0);
					     break; 
                       }
        break;

		case WM_DESTROY: 
			 PostQuitMessage(0);
	    break;
       }
return DefWindowProc(hWnd, message, wParam, lParam); 
}









