//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Menu.rc
//
#define IDR_MENU1                       101
#define IDB_BITMAP1                     103
#define IDD_DIALOG1                     104
#define ICON                            104
#define ID_NEW                          40001
#define ID_OPEN                         40002
#define ID_SAVE                         40003
#define ID_EXIT                         40004
#define ID_ABOUT                        40005
#define ID90                            40006
#define ID180                           40007
#define IDX2                            40008
#define IDX4                            40009
#define ID_OPENWMF                      40010
#define ID_SAVEWMF                      40011
#define ID_OPENMETAFILE1                40012
#define ID_OPENMETAFILE2                40013
#define ID_OPENMETAFILE3                40014
#define ID_SAVEMETAFILE1                40016
#define ID_SAVEMETAFILE2                40017
#define ID_SAVEMETAFILE3                40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
