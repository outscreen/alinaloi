# include "windows.h"
# include "resource.h"


HINSTANCE hInst;
ATOM     MyRegisterClass(HINSTANCE hInstance);
BOOL     InitInstance(HINSTANCE,int);
LRESULT CALLBACK   WndProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM); 
void CreateBMPFile( LPTSTR, PBITMAPINFO,  
                  HBITMAP, HDC) ;
PBITMAPINFO CreateBitmapInfoStruct(HBITMAP);
// �������� ��������� 

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	MSG msg;

	// ����������� ������ ���� 
	MyRegisterClass(hInstance);

	// �������� ���� ����������
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	// ���� ��������� ���������
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
	}
	return msg.wParam;
}

//  FUNCTION: MyRegisterClass()
//  ������������ ����� ���� 
    
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex; 
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style			= CS_HREDRAW|CS_VREDRAW ;	// ����� ����
	wcex.lpfnWndProc	= (WNDPROC)WndProc; // ������� ���������
	wcex.cbClsExtra		= 0;						
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;		// ��������� ����������
	wcex.hIcon			= LoadIcon(NULL,IDI_ASTERISK);		// ����������� ������
	wcex.hCursor		= LoadCursor(NULL,IDC_ARROW ); 
// ����������� �������
	wcex.hbrBackground	= (HBRUSH)GetStockObject (LTGRAY_BRUSH );
// ��������� ����
	wcex.lpszMenuName	= (LPCSTR)IDR_MENU1;// ����������� ����
	wcex.lpszClassName	= "SKS 99-1";	// ��� ������
	wcex.hIconSm		= NULL;
   
	return RegisterClassEx(&wcex); // ����������� ������ ����
}

// FUNCTION: InitInstance(HANDLE, int)
// ������� ���� ���������� � ��������� ��������� ���������� � ���������� hInst

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   static HWND hWnd;

   hInst = hInstance; // ��������� ��������� ���������� � ���������� hInst

   hWnd=CreateWindow("SKS 99-1", // ��� ������ ����
 "�������� ������ `����������� ��������`",   // ��� ����������
 WS_SYSMENU|WS_MINIMIZEBOX,//|WS_MINIMIZEBOX, // ����� ����
 100,	// ��������� �� �
 70, 	// ��������� �� Y
 650, //CW_USEDEFAULT,    // ������ �� �
 455,// CW_USEDEFAULT,    // ������ �� Y
 NULL,	// ��������� ������������� ����
 NULL,       // ��������� ���� ����
 hInstance,  // ��������� ����������
 NULL);     // ��������� ��������.


   
   if (!hWnd) // ���� ���� �� ���������, ������� ���������� FALSE
   {
      return FALSE;
   }
   ShowWindow(hWnd, nCmdShow);		// �������� ����
   UpdateWindow(hWnd);			// �������� ����
   return TRUE;				//�������� ���������� �������
}

//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//  ������� ���������. ��������� � ������������ ���
//	���������, ���������� � ����������




LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   static HDC hdc,hCompatibleDC,h2CompatibleDC,hMemDC,hMetaFileDC;
   PAINTSTRUCT ps;
   static HANDLE hBitmap,hOldBitmap,h2Bitmap,h2OldBitmap,h5Bitmap,h5OldBitmap;
   RECT rt; 
   static nHorizPosition=0,nVertPosition=0;
   static int posx,posy,xpos,ypos;
   static HWND hButton1,hButton2,hButton3, hButton4,hButton5,hButton6,hCButton1,hCButton2,hCButton3,hCButton4,hEdit1;
   static int Col1,Col2,Col3,place;
   int wmId, wmEvent;
   static bool rect;
    static bool ln;
	static bool el;
	static bool tex;
	static bool n;
	static bool tr;
	static BOOL meta;
	static HMETAFILE hMetaFile,hMetaF;
	BITMAP Bitmap;
   HPEN hOldPen;
   HPEN Pen;
   HBRUSH hOldBrush;
   HBRUSH Brush; 
   char lpstrFile[100]="";
     OPENFILENAME OpenFileName;

	 switch (message) 
	{

		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:

		switch (wmId)
			{
			   case ID_EXIT:
				   DestroyWindow(hWnd);
			   break;

			   case 1:
				   {
					   SendMessage(hButton1,BM_SETSTATE,BST_CHECKED,0);
					   SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
					   ln=true;	
				       rect=false;
                       el=false;
					   tex=false;
				   }
				   break;
			   case 2:
				   {
					   SendMessage(hButton2,BM_SETSTATE,BST_CHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
					   rect=true;
				       ln=false;
				       el=false;
					   tex=false;
				   }
				   break;
			   case 3:
				   {
					   SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_CHECKED,0);  
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
					   el=true;
				       rect=false;
				       ln=false;
					   tex=false;
				   }
				   break;
			   case 4:
				   {
                       SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0); 
					   SendMessage(hButton4,BM_SETSTATE,BST_CHECKED,0);  
					   el=false;
				       rect=false;
				       ln=false;
					   tex=true;
				   }
				   break;
			   case 5:
				   {
					   SendMessage(hCButton1,BM_SETSTATE,BST_CHECKED,0);  
					   SendMessage(hCButton2,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hCButton3,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hCButton4,BM_SETSTATE,BST_UNCHECKED,0);
                       Col1=255;
					   Col2=0;
					   Col3=0;
				   }
				   break;
			   case 6:
				   {
                       SendMessage(hCButton1,BM_SETSTATE,BST_UNCHECKED,0);  
					   SendMessage(hCButton2,BM_SETSTATE,BST_CHECKED,0);
					   SendMessage(hCButton3,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hCButton4,BM_SETSTATE,BST_UNCHECKED,0);
                       Col1=0;
					   Col2=255;
					   Col3=0; 
				   }
				   break;
			   case 7:
				   {
				       SendMessage(hCButton1,BM_SETSTATE,BST_UNCHECKED,0);  
					   SendMessage(hCButton2,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hCButton3,BM_SETSTATE,BST_CHECKED,0);
					   SendMessage(hCButton4,BM_SETSTATE,BST_UNCHECKED,0);
                       Col1=0;
					   Col2=0;
					   Col3=255;
				   }
				   break;
			   case 8:
				   {
				       SendMessage(hCButton1,BM_SETSTATE,BST_UNCHECKED,0);  
					   SendMessage(hCButton2,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hCButton3,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hCButton4,BM_SETSTATE,BST_CHECKED,0);
                       Col1=255;
					   Col2=0;
					   Col3=255;
				   }
				   break;
               case 12:
				   {
					   {
		   hdc=GetDC(hWnd);
           hMemDC=(HDC)CreateCompatibleDC(hdc);
	       h2Bitmap=(HBITMAP)CreateCompatibleBitmap(hdc,450,400);
   		   h2OldBitmap=SelectObject(hMemDC,h2Bitmap);
		      Pen=(CreatePen(PS_SOLID,2,RGB(0,0,0))); //��������� �������
			  Brush=(CreateSolidBrush(RGB(0,0,0)));
			  hOldPen=(HPEN)SelectObject(hMemDC,Pen);
			  hOldBrush=(HBRUSH)SelectObject(hMemDC,Brush);
			  Rectangle(hMemDC,0,0,450,400);
              SelectObject(hMemDC,Pen);
			  SelectObject(hMemDC,Brush);
			  DeleteObject(Pen);
			  DeleteObject(Brush);
					
                   	   int x,y,sourcex,sourcey;
	                   int cosine=0;//(float)cos(0);
    	               int sine =1;//(float)sin(100);
      
       for (y=0;y<400;y++)
	     for(x=0;x<450;x++)
	  	   {
			   sourcex=(int)(x*cosine-y*sine+450);
		       sourcey=(int)(x*sine+y*cosine);
	   if (sourcex>=0)
		   if(sourcex<450)
			   if(sourcey>=0)
				   if(sourcey<400)
			   {
				   SetPixel(hMemDC,sourcex,sourcey,GetPixel(hCompatibleDC,x,y));//GetPixel(hCompatibleDC,440,390));
			   }
				  

	   
		   }

			       SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0); 
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
              
			            	ln=false;
			                rect=false;
			                el=false;
			                tex=false;
			                			
						
		   hBitmap=h2Bitmap;
		   hCompatibleDC=hMemDC;
	       ReleaseDC(hWnd,hdc);
		   GetClientRect(hWnd,&rt);
		   InvalidateRect(hWnd,&rt,FALSE);
	   }
				   }
				   break;
	 case 13:
	  {
		   hdc=GetDC(hWnd);
           hMemDC=(HDC)CreateCompatibleDC(hdc);
	       h2Bitmap=(HBITMAP)CreateCompatibleBitmap(hdc,450,400);
		   h2OldBitmap=SelectObject(hMemDC,h2Bitmap);               
			  Pen=(CreatePen(PS_SOLID,2,RGB(0,0,0))); 
			  Brush=(CreateSolidBrush(RGB(0,0,0)));
			  hOldPen=(HPEN)SelectObject(hMemDC,Pen);
			  hOldBrush=(HBRUSH)SelectObject(hMemDC,Brush);
			  Rectangle(hMemDC,0,0,450,400);
              SelectObject(hMemDC,Pen);
			  SelectObject(hMemDC,Brush);
			  DeleteObject(Pen);
			  DeleteObject(Brush);	
           int x,y;
	   int sourcex,sourcey;
		   sourcex=0;
		   sourcey=0;
	   for (y=1;y<400;y)
	   {
		   sourcex=0;
	     for(x=1;x<450;x)
	  	   {
			    SetPixel(hMemDC,sourcex,sourcey,GetPixel(hCompatibleDC,x,y));//GetPixel(hCompatibleDC,440,390));
			   	
			   sourcex=(sourcex+1);
			   x=x+2;
		   }
		 sourcey=(sourcey+1);
		 y=y+2;
	  }    SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0); 
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
              
			            	ln=false;
			                rect=false;
			                el=false;
			                tex=false;
		   hBitmap=h2Bitmap;
		   hCompatibleDC=hMemDC;
	       ReleaseDC(hWnd,hdc);
		   GetClientRect(hWnd,&rt);
		   InvalidateRect(hWnd,&rt,FALSE);
	   }
				   break;
	 case ID90:
		 SendMessage(hWnd,WM_COMMAND,12,NULL);
		 break;

	 case ID180:
         SendMessage(hWnd,WM_COMMAND,12,NULL);
		 SendMessage(hWnd,WM_COMMAND,12,NULL);
		 break;
	 case IDX2:
		 SendMessage(hWnd,WM_COMMAND,13,NULL);
		 break;
	 case IDX4:
		 SendMessage(hWnd,WM_COMMAND,13,NULL);
		 SendMessage(hWnd,WM_COMMAND,13,NULL);
		 break;
		 
	 case ID_SAVE:
		 PBITMAPINFO Info;
OpenFileName.lStructSize =sizeof(OPENFILENAME);
OpenFileName.hwndOwner =GetParent(hWnd);
OpenFileName.hInstance =NULL;
OpenFileName.lpstrFilter ="Applications Extension(*.bmp)\0*.bmp\0\0";
OpenFileName.lpstrCustomFilter =NULL;
OpenFileName.nFilterIndex =0;
OpenFileName.lpstrFile =lpstrFile;
OpenFileName.nMaxFile =MAX_PATH;
OpenFileName.lpstrFileTitle =NULL;
OpenFileName.lpstrInitialDir =NULL;
OpenFileName.lpstrTitle= "���������";
OpenFileName.Flags =OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_LONGNAMES|OFN_PATHMUSTEXIST;
OpenFileName.lpstrDefExt =NULL;
if(GetSaveFileName(&OpenFileName))
{
	HBITMAP hBiTmap;
	hBiTmap=(HBITMAP)hBitmap;
	PBITMAPINFO CreateBitmapInfoStruct( HBITMAP hBmp);
    strcat(OpenFileName.lpstrFile ,".bmp");
Info=CreateBitmapInfoStruct(hBiTmap);
CreateBMPFile(OpenFileName.lpstrFile ,Info,hBiTmap,hCompatibleDC);
	
}
		 break;

     case ID_OPENMETAFILE1:
            hMetaFile=GetMetaFile("Meta.wmf");
			meta=true;
			GetClientRect(hWnd,&rt);
		    InvalidateRect(hWnd,&rt,FALSE);
		 break;

		  case ID_OPENMETAFILE2:
            hMetaFile=GetMetaFile("Meta2.wmf");
			meta=true;
			GetClientRect(hWnd,&rt);
		    InvalidateRect(hWnd,&rt,FALSE);
		 break;

		  case ID_OPENMETAFILE3:
            hMetaFile=GetMetaFile("Meta3.wmf");
			meta=true;
			GetClientRect(hWnd,&rt);
		    InvalidateRect(hWnd,&rt,FALSE);
		 break;


		  case ID_SAVEMETAFILE1:
			  	 hMetaF=CloseMetaFile(hMetaFileDC); 
			  	 CopyMetaFile(hMetaF,"Meta.wmf");
			    
			  break;
		  case ID_SAVEMETAFILE2:
			  hMetaF=CloseMetaFile(hMetaFileDC);
                 CopyMetaFile(hMetaF,"Meta2.wmf"); 
			  break;
          case ID_SAVEMETAFILE3: 
			  hMetaF=CloseMetaFile(hMetaFileDC);
                 CopyMetaFile(hMetaF,"Meta3.wmf"); 
			  break;  


	 case ID_OPEN:
		 {
			
		 
		 		OpenFileName.lStructSize =sizeof(OPENFILENAME);
                OpenFileName.hwndOwner =GetParent(hWnd);
                OpenFileName.hInstance =NULL;
                OpenFileName.lpstrFilter ="Applications Extension(*.bmp)\0*.bmp\0\0";
                OpenFileName.lpstrCustomFilter =NULL;
                OpenFileName.nFilterIndex =0;
OpenFileName.lpstrFile =lpstrFile;
OpenFileName.nMaxFile =MAX_PATH;
OpenFileName.lpstrFileTitle =NULL;
OpenFileName.lpstrInitialDir =NULL;
OpenFileName.lpstrTitle= "Open File";
OpenFileName.Flags =OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_LONGNAMES|OFN_PATHMUSTEXIST;
OpenFileName.lpstrDefExt =NULL;
if(GetOpenFileName(&OpenFileName))
{

DeleteObject(hBitmap);
hBitmap=(HBITMAP)LoadImage(NULL,OpenFileName.lpstrFile ,
				IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
GetObject(hBitmap,sizeof(BITMAP),&Bitmap);
}
SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0); 
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
	          ln=false;
			  rect=false;
			  el=false;
			  tex=false;
         GetClientRect(hWnd,&rt);
		 InvalidateRect(hWnd,&rt,TRUE);
}
		 break;
				    case ID_NEW:
				       SendMessage(hButton2,BM_SETSTATE,BST_UNCHECKED,0);
                       SendMessage(hButton1,BM_SETSTATE,BST_UNCHECKED,0);
					   SendMessage(hButton3,BM_SETSTATE,BST_UNCHECKED,0); 
					   SendMessage(hButton4,BM_SETSTATE,BST_UNCHECKED,0);  
              
		      ln=false;
			  rect=false;
			  el=false;
			  tex=false;
			  n=true; 
       	 GetClientRect(hWnd,&rt);
		 InvalidateRect(hWnd,&rt,FALSE);
				  break;
			   case ID_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_DIALOG1, hWnd, (DLGPROC)About);
				   break;
			   
				  
 			   default:
			   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;

			
		case WM_LBUTTONDOWN:
		xpos=LOWORD(lParam);
		ypos=HIWORD(lParam);
		break;
     case WM_LBUTTONUP:
        posx=LOWORD(lParam);
        posy=HIWORD(lParam);
        GetClientRect(hWnd,&rt);
		InvalidateRect(hWnd,&rt,FALSE);
        break;

	 case WM_CREATE:
		 n=true;
		 hButton1=CreateWindow("BUTTON","Line",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,460,0,80,70,hWnd,(HMENU)1,hInst,NULL);
				hButton2=CreateWindow("BUTTON","Rectangle",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,540,0,80,70,hWnd,(HMENU)2,hInst,NULL);
				hButton3=CreateWindow("BUTTON","Ellipse",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,460,70,80,70,hWnd,(HMENU)3,hInst,NULL);
				hButton4=CreateWindow("BUTTON","Text",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,540,70,80,70,hWnd,(HMENU)4,hInst,NULL);
				hCButton1=CreateWindow("BUTTON","RED",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,460,160,60,30,hWnd,(HMENU)5,hInst,NULL);
				hCButton2=CreateWindow("BUTTON","GREEN",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,460,190,60,30,hWnd,(HMENU)6,hInst,NULL);
				hCButton3=CreateWindow("BUTTON","BLUE",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,530,160,60,30,hWnd,(HMENU)7,hInst,NULL);
				hCButton4=CreateWindow("BUTTON","MAGENA",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,530,190,60,30,hWnd,(HMENU)8,hInst,NULL);
				hEdit1= CreateWindow("edit",NULL,WS_CHILD|WS_VISIBLE|WS_BORDER|
		                                            ES_LEFT|ES_NOHIDESEL|ES_AUTOHSCROLL,
						                            460,240,120,20,hWnd,(HMENU)10,
						                            hInst,NULL);
         hButton5=CreateWindow("BUTTON","Rotate 90%",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,460,300,80,70,hWnd,(HMENU)12,hInst,NULL);
         hButton6=CreateWindow("BUTTON","Macshtab",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,550,300,80,70,hWnd,(HMENU)13,hInst,NULL); 
		 hdc=GetDC(hWnd);
         hCompatibleDC=(HDC)CreateCompatibleDC(hdc);
		 hBitmap=(HBITMAP)CreateCompatibleBitmap(hdc,450,400);
		 hOldBitmap=SelectObject(hCompatibleDC,hBitmap);
           hMetaFileDC=CreateMetaFile(NULL);
             		   
		 
		 ReleaseDC(hWnd,hdc);
		break;

 	case WM_PAINT:  
	   hdc=BeginPaint(hWnd, &ps);
	   SelectObject(hCompatibleDC,hBitmap);
	 	GetClientRect(hWnd,&rt);
        SetBkColor   (hdc,GetSysColor (4)) ;
		
      TextOut(hdc,460,225,"Type you text:",14);
		if (n==true)
			{
			  Pen=(CreatePen(PS_SOLID,2,RGB(0,0,0)));
			  Brush=(CreateSolidBrush(RGB(0,0,0)));
			  hOldPen=(HPEN)SelectObject(hCompatibleDC,Pen);
			  hOldBrush=(HBRUSH)SelectObject(hCompatibleDC,Brush);
			  Rectangle(hCompatibleDC,0,0,450,400);
			  SelectObject(hCompatibleDC,Pen);
			  SelectObject(hCompatibleDC,Brush);
			  DeleteObject(Pen);
			  DeleteObject(Brush);
			  meta=false;
				n=false;
			}
				if (rect==true)
				{
			   Pen=(CreatePen(PS_SOLID,2,RGB(Col1,Col2,Col3)));
			   Brush=(CreateSolidBrush(RGB(Col1,Col2,Col3)));
			   hOldPen=(HPEN)SelectObject(hCompatibleDC,Pen);
			   hOldBrush=(HBRUSH)SelectObject(hCompatibleDC,Brush);
			   Rectangle(hCompatibleDC,posx,posy,xpos,ypos);
			   SelectObject(hCompatibleDC,Pen);
			   SelectObject(hCompatibleDC,Brush);
			   DeleteObject(Pen);
			   DeleteObject(Brush);

			   Pen=(CreatePen(PS_SOLID,2,RGB(Col1,Col2,Col3)));
			   Brush=(CreateSolidBrush(RGB(Col1,Col2,Col3)));
			   hOldPen=(HPEN)SelectObject(hMetaFileDC,Pen);
			   hOldBrush=(HBRUSH)SelectObject(hMetaFileDC,Brush);
			   Rectangle(hMetaFileDC,posx,posy,xpos,ypos);
               SelectObject(hMetaFileDC,Pen);
			   SelectObject(hMetaFileDC,Brush);
			   DeleteObject(Pen);
			   DeleteObject(Brush);

				}
                if (ln==true)
				{
					
				Pen=(CreatePen(PS_SOLID,2,RGB(Col1,Col2,Col3)));
			    hOldPen=(HPEN)SelectObject(hdc,Pen);
			    SelectObject(hCompatibleDC,Pen);
			    MoveToEx(hCompatibleDC,xpos,ypos,NULL);
			    LineTo(hCompatibleDC,posx,posy);
				SelectObject(hCompatibleDC,Pen);
			    DeleteObject(Pen);
			  
				Pen=(CreatePen(PS_SOLID,2,RGB(Col1,Col2,Col3)));
			    hOldPen=(HPEN)SelectObject(hMetaFileDC,Pen);
			    SelectObject(hMetaFileDC,Pen);
			    MoveToEx(hMetaFileDC,xpos,ypos,NULL);
			    LineTo(hMetaFileDC,posx,posy);
				SelectObject(hMetaFileDC,Pen);
			    DeleteObject(Pen);
				}
				if (el==true)
				{
			   Pen=(CreatePen(1,2,RGB(Col1,Col2,Col3)));
			   Brush=(CreateSolidBrush(RGB(Col1,Col2,Col3)));
			   hOldPen=(HPEN)SelectObject(hdc,Pen);
			   hOldBrush=(HBRUSH)SelectObject(hdc,Brush);
			   SelectObject(hCompatibleDC,Pen);
			   SelectObject(hCompatibleDC,Brush);
               Ellipse(hCompatibleDC,posx,posy,xpos,ypos);
			   SelectObject(hCompatibleDC,Pen);
			   SelectObject(hCompatibleDC,Brush);
			   DeleteObject(Pen);
			   DeleteObject(Brush);

			   Pen=(CreatePen(1,2,RGB(Col1,Col2,Col3)));
			   Brush=(CreateSolidBrush(RGB(Col1,Col2,Col3)));
			   hOldPen=(HPEN)SelectObject(hMetaFileDC,Pen);
			   hOldBrush=(HBRUSH)SelectObject(hMetaFileDC,Brush);
			   SelectObject(hMetaFileDC,Pen);
			   SelectObject(hMetaFileDC,Brush);
               Ellipse(hMetaFileDC,posx,posy,xpos,ypos);
			   SelectObject(hMetaFileDC,Pen);
			   SelectObject(hMetaFileDC,Brush);
			   DeleteObject(Pen);
			   DeleteObject(Brush);

				}
				if (tex==true)
				{
			      char texx[10];
				  int i;

				  SetTextColor (hCompatibleDC, RGB(Col1,Col2,Col3)) ;
				  SetBkMode(hCompatibleDC,0);
                  SendMessage(hEdit1,EM_GETLINE,(WPARAM)1,(LPARAM)texx);
				  i=0;
				  while (texx[i])
					  i++;
				  TextOut(hCompatibleDC,posx,posy,texx,i);

				  SetTextColor (hMetaFileDC, RGB(Col1,Col2,Col3)) ;
				  SetBkMode(hMetaFileDC,0);
				  TextOut(hMetaFileDC,posx,posy,texx,i);

				}
     if(meta == true)
       
		{
	
			 PlayMetaFile (hCompatibleDC, hMetaFile) ;
			 meta=false;
		}
		
		BitBlt(hdc,0,0,450,400,hCompatibleDC,nHorizPosition,nVertPosition,SRCCOPY);
		
		EndPaint(hWnd, &ps);

		return 0;


		case WM_DESTROY:
		
			SelectObject(hCompatibleDC,hOldBitmap);
            DeleteObject(hBitmap);
			DeleteMetaFile(hMetaFile);
            DeleteDC(hCompatibleDC);
           PostQuitMessage(0);
		break;


		default: 
		return DefWindowProc(hWnd, message, wParam, lParam); 
   }
return 0;

}

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}  

PBITMAPINFO CreateBitmapInfoStruct(HBITMAP hBmp) {  
    BITMAP bmp; 
    PBITMAPINFO pbmi; 
    WORD    cClrBits; 
 
   
 
    if (!GetObject(hBmp, sizeof(BITMAP), (LPSTR)&bmp)) 
      
 
    
 
    cClrBits = (WORD)(bmp.bmPlanes * bmp.bmBitsPixel); 
 
    if (cClrBits == 1) 
        cClrBits = 1; 

    else if (cClrBits <= 4) 
        cClrBits = 4; 
    else if (cClrBits <= 8) 
        cClrBits = 8; 
    else if (cClrBits <= 16) 
        cClrBits = 16; 
    else if (cClrBits <= 24) 
        cClrBits = 24; 
    else 
        cClrBits = 32; 
 
  
 
    if (cClrBits != 24) 
         pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 

                    sizeof(BITMAPINFOHEADER) + 
                    sizeof(RGBQUAD) * (2^cClrBits)); 
 
 
 
    else 
         pbmi = (PBITMAPINFO) LocalAlloc(LPTR, 
                    sizeof(BITMAPINFOHEADER)); 
 
 
 
  
 
    pbmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER); 
    pbmi->bmiHeader.biWidth = bmp.bmWidth; 

    pbmi->bmiHeader.biHeight = bmp.bmHeight; 
    pbmi->bmiHeader.biPlanes = bmp.bmPlanes; 
    pbmi->bmiHeader.biBitCount = bmp.bmBitsPixel; 
    if (cClrBits < 24) 
        pbmi->bmiHeader.biClrUsed = 2^cClrBits; 
 
 
 
    pbmi->bmiHeader.biCompression = BI_RGB; 
 
   

 
    pbmi->bmiHeader.biSizeImage = (pbmi->bmiHeader.biWidth + 7) /8 
                                  * pbmi->bmiHeader.biHeight 
                                  * cClrBits; 
 
    
 
    pbmi->bmiHeader.biClrImportant = 0; 
 
    return pbmi; 
 
} 




void CreateBMPFile( LPTSTR pszFile, PBITMAPINFO pbi,  
                  HBITMAP hBMP, HDC hDC) 
 { 
 
    HANDLE hf;                 
    BITMAPFILEHEADER hdr;       
    PBITMAPINFOHEADER pbih;     
    LPBYTE lpBits;             
    DWORD dwTotal;            
    DWORD cb;           
    BYTE *hp;                  
const int MAXWRITE=16;
    DWORD dwTmp; 
 
 
    pbih = (PBITMAPINFOHEADER) pbi; 
    lpBits = (LPBYTE) GlobalAlloc(GMEM_FIXED, pbih->biSizeImage);
 
 
    if (!GetDIBits(hDC, hBMP, 0, (WORD) pbih->biHeight, 
		lpBits, pbi, DIB_RGB_COLORS)) {MessageBox(NULL,"","",MB_OK);}
       
 
    
 
    hf = CreateFile(pszFile, 
                    GENERIC_WRITE, 
                   0	, 
                   (LPSECURITY_ATTRIBUTES) NULL, 
                   CREATE_ALWAYS, 
                   FILE_ATTRIBUTE_NORMAL, 
                   (HANDLE) NULL); 
 
    if (hf == INVALID_HANDLE_VALUE) 
	{;}
 
    hdr.bfType = 0x4d42;       
 
    hdr.bfSize = (DWORD) (sizeof(BITMAPFILEHEADER) + 
                 pbih->biSize + pbih->biClrUsed 
                 * sizeof(RGBQUAD) + pbih->biSizeImage); 
 
    hdr.bfReserved1 = 0; 
    hdr.bfReserved2 = 0; 
 
 
    hdr.bfOffBits = (DWORD) sizeof(BITMAPFILEHEADER) + 
                    pbih->biSize + pbih->biClrUsed 
                    * sizeof (RGBQUAD);

 
 

 
    if (!WriteFile(hf, (LPVOID) &hdr, sizeof(BITMAPFILEHEADER), 
		(LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) {
		
		MessageBox(NULL,"Her","",MB_OK);}
      
 
  
 char q1[10];
 itoa(pbih->biSize,q1,10);
 
    if (!WriteFile(hf, (LPVOID) pbih, sizeof(BITMAPINFOHEADER) 
                  + pbih->biClrUsed * sizeof (RGBQUAD), 
                  (LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
      	{ 
		;}
 

 
    dwTotal = cb = pbih->biSizeImage; 
    hp = lpBits; 
    while (cb > MAXWRITE)  { 
            if (!WriteFile(hf, (LPSTR) hp, (int) MAXWRITE, 
                          (LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
			{;} 
            cb-= MAXWRITE; 
            hp += MAXWRITE; 
    } 
    if (!WriteFile(hf, (LPSTR) hp, (int) cb, 
         (LPDWORD) &dwTmp, (LPOVERLAPPED) NULL)) 
	{;}

 
   
 
    if (!CloseHandle(hf)) 
	{;}
 

    GlobalFree((HGLOBAL)lpBits);
} 




