#include <windows.h>         // ����������� ���������� � ��������� API
#include <commdlg.h>
#include "resource.h"
#include <mmsystem.h>
#include <stdio.h>
#include <math.h>
// ���������� ����������:
HINSTANCE hInst; 	// ��������� ����������
HMENU hMenu;
HICON hIcon;
HCURSOR hCursor;
int text_up,round,color,cout,choiceText,kol,lives,stena,radius,speed,text_right,text_left,i,ii,j,jj,x,y,x2,y2,xm,ym,xk,yk,xb,yb;
int iSelection =ID_NORM,
iSelection1=ID_MOUSE,
iSelection2=ID_SOUND;
int mass[3][9]= {
	{1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1},
	{1,1,1,1,1,1,1,1,1}
};
double ugol,c,z;
char A[10];
unsigned long ball_color,kubik_color,desk_color;
bool klava,risovanie,polet,kub,mouse_click,sound,g=false;
HBRUSH ball_brush,kubik_brush,desk_brush;
// ��������������� �������� �������
ATOM		MyRegisterClass(HINSTANCE hInstance);
BOOL		InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
// �������� ��������� 

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{  
	text_right=700;
	text_left=-70;
	choiceText=1;
	speed=70000;
	lives=2;
	round=0;
	cout=0;
	xk=100;
	yk=100;
	xm=350;
	ym=250;
	
	
	MSG msg;
	
	// ����������� ������ ���� 
	MyRegisterClass(hInstance);
	
	// �������� ���� ����������
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}
	// ���� ��������� ���������
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

//  FUNCTION: MyRegisterClass()
//  ������������ ����� ���� 

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex; 
	wcex.cbSize			= sizeof(WNDCLASSEX); 
	wcex.style			= CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;		// ����� ����
	wcex.lpfnWndProc	= (WNDPROC)WndProc;							// ������� ���������
	wcex.cbClsExtra		= 0;						
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;								// ��������� ����������
	wcex.hIcon			= LoadIcon(hInstance,LPCSTR(IDI_ICON1));	// ����������� ������
	wcex.hCursor		= LoadCursor(hInstance,LPCSTR(IDC_CURSOR1));// ����������� �������
	wcex.hbrBackground	= (HBRUSH)GetStockObject(4);				// ��������� ����
	wcex.lpszMenuName	= NULL;										// ����������� ����
	wcex.lpszClassName	= "PonomarenkoAA";							// ��� ������
	wcex.hIconSm		= NULL;
	
	return RegisterClassEx(&wcex); // ����������� ������ ����
}


// FUNCTION: InitInstance(HANDLE, int)
// ������� ���� ���������� � ��������� ��������� ���������� � ���������� hInst

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	HWND hWnd;
	hInst = hInstance; // ��������� ��������� ���������� � ���������� hInst
	
	hWnd=CreateWindow("PonomarenkoAA",			   // ��� ������ ����
		"� � � � � � � �",							   // ��� ����������
		WS_CAPTION|WS_SYSMENU|WS_VISIBLE|WS_MINIMIZEBOX,// ����� ����
		0,											   // ��������� �� �
		0, 											   // ��������� �� Y
		700,											   // ������ �� �
		520,											   // ������ �� Y
		NULL,										   // ��������� ������������� ����
		NULL,										   // ��������� ���� ����
		hInstance,									   // ��������� ����������
		NULL);										   // ��������� ��������.
	
	if (!hWnd) // ���� ���� �� ���������, ������� ���������� FALSE
	{
		return FALSE;
	}
	ShowWindow(hWnd, nCmdShow);	// �������� ����
	UpdateWindow(hWnd);			// �������� ����
	return TRUE;				    //�������� ���������� �������
}

//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//  ������� ���������. ��������� � ������������ ���
//	���������, ���������� � ����������

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	RECT rect,rect1,rect2,rect3;
	PAINTSTRUCT ps;
	POINT pt;
	HDC hdc;
	
	static CHOOSECOLOR cc;
	static COLORREF crCustColors[16];
	
	cc.lStructSize = sizeof (CHOOSECOLOR);
	cc.hwndOwner   = NULL;
	cc.hInstance   = NULL;
	cc.rgbResult   = RGB (0x80,0x80,0x80);
	cc.lpCustColors= crCustColors;
	cc.Flags       = CC_RGBINIT | CC_FULLOPEN;
	cc.lCustData   = 0L;
	cc.lpfnHook    = NULL;
	cc.lpTemplateName= NULL;
	
	if(risovanie==false)
	{				
		Sleep(12);
		if(text_right==-250) text_right=700;
		if(text_left==750) text_left=-70;
		text_right=text_right-1;
		text_left=text_left+1;
		hdc = BeginPaint(hWnd, &ps);
		SetTextColor(hdc,RGB(200,0,0));
		SetBkColor(hdc,TRANSPARENT);			
		if(choiceText==1)
		{
			TextOut(hdc,text_left,180," � � � � � � � �",16);
			TextOut(hdc,text_right,450,"Press Enter for begin",21);
		}
		if(choiceText==2)
		{
			TextOut(hdc,text_left,180,"� � � � �",9);
			TextOut(hdc,text_right,450,"Press Enter for continue",24);
		}
		if(choiceText==3)
		{
			SetTextColor(hdc,RGB(0,i,0));
			SetBkMode(hdc,TRANSPARENT);
			TextOut(hdc,300,200,"G A M E  O V E R",16);
			TextOut(hdc,290,240,"YOU SCORES - ",13);
			if(cout==0) kol=1;
			TextOut(hdc,390,240,A,kol);
			i++;
			if(i==255){InvalidateRect(hWnd,NULL,true);choiceText=1;text_right=700;text_left=-70;ShowCursor(true);if(sound==false)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);}
		}
		if(choiceText==4)
		{
			SetTextColor(hdc,RGB(0,i,0));
			SetBkMode(hdc,TRANSPARENT);
			TextOut(hdc,250,200,"CONGRATULATION !!! YOU WIN !!!",30);
			TextOut(hdc,300,250,"YOU SCORES - ",13);
			TextOut(hdc,400,250,A,4);
			i++;
			if(i==255){InvalidateRect(hWnd,NULL,true);Sleep(500);choiceText=6;text_up=600;if(sound==false)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);}
		}
		if(choiceText==5)
		{
			SetTextColor(hdc,RGB(0,0,i));
			SetBkMode(hdc,TRANSPARENT);
			if(cout==2700)TextOut(hdc,300,200,"ROUND 2",7);
			if(cout==4100)TextOut(hdc,300,200,"ROUND 3",7);
			if(round==0)TextOut(hdc,300,200,"ROUND 1",7);
			i++;
			if(i==255)
			{
				InvalidateRect(hWnd,NULL,true);
				if(sound==false)PlaySound("round.wav",NULL,SND_FILENAME|SND_SYNC);
				if(round==0 && sound==false)PlaySound("1.wav",NULL,SND_FILENAME|SND_SYNC);
				if(cout==2700 && sound==false)PlaySound("2.wav",NULL,SND_FILENAME|SND_SYNC);
				if(cout==4100 && sound==false)PlaySound("3.wav",NULL,SND_FILENAME|SND_SYNC);
				if(klava==true)x2=350;
				SetCursorPos(xm,ym);
				risovanie=true;
			}
		}
		if(choiceText==6)
		{
			SetTextColor(hdc,RGB(0,0,255));
			SetBkColor(hdc,TRANSPARENT);
			TextOut(hdc,300,text_up,"� � � � � � � �",15);
			TextOut(hdc,100,text_up+100,"� �������� ���� ���� ��������� :",32);
			TextOut(hdc,200,text_up+150,"���� :                                    ���� �.�.",51);
			TextOut(hdc,200,text_up+200,"���������� :                       ����� �.�.            ",51);
			TextOut(hdc,200,text_up+250,"��������������� :           ������� �.�.",40);
			TextOut(hdc,393,text_up+275,"���� �.�.",9);
			TextOut(hdc,200,text_up+350,"����������� ������ :     ����� �.�.",35);
			TextOut(hdc,200,text_up+400,"������������ ������ : ������� �.�.",34);
			TextOut(hdc,200,text_up+800,"������� �� ������ ������ , ������� ���",38);
			TextOut(hdc,290,text_up+850,"� � � � � � �  2001",19);
			text_up=text_up-1;
			if(text_up==-900){Sleep(500);choiceText=1;text_right=700;text_left=-70;ShowCursor(true);if(sound==false)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);}
		}
		if(choiceText==7)
		{
			SetTextColor(hdc,RGB(0,0,i));
			SetBkColor(hdc,TRANSPARENT);
			TextOut(hdc,300,200,"READY !!!",9);
			i++;
			if(i==255)
			{InvalidateRect(hWnd,NULL,true);risovanie=true;}
		}
		if(g==false)		
			InvalidateRect(hWnd,NULL,false);
		EndPaint(hWnd, &ps);
	}
	
	switch (message)
	{
	case WM_CREATE: // ��������� �������� ��� �������� ����
		hMenu=LoadMenu(hInst,LPCTSTR(IDR_MENU1));// ����������� ����
		SetMenu(hWnd,hMenu);					 // 
		ball_brush=CreateSolidBrush(RGB(240,240,10));
		kubik_brush=CreateSolidBrush(RGB(0,0,200));
		desk_brush=CreateSolidBrush(RGB(0,240,0));
		ball_color   = RGB (240,240,10);
		kubik_color  = RGB (0,0,250);
		desk_color   = RGB (0,240,0);
		PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);
		break;
		
	case WM_KEYDOWN:
		switch(wParam)
		{
		case VK_RETURN:
			InvalidateRect(hWnd,NULL,true);
			if(risovanie==false)
			{
				kubik_brush=CreateSolidBrush(kubik_color);
				ball_brush=CreateSolidBrush(ball_color);
				desk_brush=CreateSolidBrush(desk_color);
			}
			if(choiceText==2 && risovanie==false)
			{
				if(sound==false)PlaySound("pause.wav",NULL,SND_FILENAME|SND_ASYNC);
				SetCursorPos(xm,ym);		 
				ShowCursor(false);
				risovanie=true;
			}
			if(choiceText==5 && risovanie==false)
			{
				risovanie=true;
				PlaySound(0,0,SND_PURGE);
				SetCursorPos(xm,ym);
				if(klava==true)x2=350;
			}	
			if(choiceText==1 )
			{
				choiceText=5;
				i=0;
				ShowCursor(false);
			}
			if(choiceText==3 || choiceText==4)
			{
				ShowCursor(true);
				choiceText=1;
				if(sound==false)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);
			} 
			break;
			
		case VK_PAUSE:
			InvalidateRect(hWnd,NULL,true);
			if(risovanie==true)
			{
				if(sound==false)PlaySound("pause.wav",NULL,SND_FILENAME|SND_ASYNC);
				GetCursorPos(&pt);
				xm=pt.x;
				ym=pt.y;
				SetCursorPos(350,250);
				risovanie=false;
				choiceText=2;
				text_right=700;	
				text_left=-70;	
				ShowCursor(true);
			}
			else 
			{     
				kubik_brush=CreateSolidBrush(kubik_color);
				ball_brush=CreateSolidBrush(ball_color);
				desk_brush=CreateSolidBrush(desk_color);
				if(choiceText==2)
				{
					if(sound==false)PlaySound("pause.wav",NULL,SND_FILENAME|SND_ASYNC);
					risovanie=true;
					SetCursorPos(xm,ym);
					ShowCursor(false);
				}
			}
			break;
			
		case VK_RIGHT:
			if(klava==true && risovanie==true)
			{	
				SetRect(&rect1,0,444,700,470);	
				InvalidateRect(hWnd,&rect1,true);
				x2=x2+50;
			}
			break;
			
		case VK_LEFT:
			if(klava==true && risovanie==true)
			{
				SetRect(&rect1,0,444,700,470);	
				InvalidateRect(hWnd,&rect1,true);
				x2=x2-50;
			}
			break;
			
		case VK_SPACE:
			if(klava==true && mouse_click==false && risovanie==true)
			{ 
				polet=true;
				mouse_click=true;	
				radius=0;
				x=xb;
				y=yb;
				xb=x2+30;
				yb=445;
				stena=1;
				ugol=3.14159/7;
			}			
			
	 	         break;
		}
		break;
		
	case WM_RBUTTONDOWN:
		if(klava==false)
			SendMessage(hWnd,WM_KEYDOWN,VK_RETURN,lParam);
		break;
		
	case WM_RBUTTONDBLCLK:
		if(klava==false)
			SendMessage(hWnd,WM_KEYDOWN,VK_PAUSE,lParam);
		break;
		
	case WM_LBUTTONDOWN:
		if(mouse_click==false && klava==false && risovanie==true)
		{  
            radius=0;
			mouse_click=true;
			polet=true;
			stena=1;
            x=xb;
			y=yb;
			yb=445;
			xb=x2+30;
			ugol=3.14159/7;
		}
		break;
		
	case WM_KILLFOCUS:
		if(risovanie==true)
		{
			InvalidateRect(hWnd,NULL,true);
			ShowCursor(true);
			choiceText=2;
			risovanie=false;
			GetCursorPos(&pt);
			xm=pt.x;
			ym=pt.y;
			text_right=700;
			text_left=-70;
		}
		break;
		
    case WM_MOUSEMOVE:
		if(klava==false && risovanie==true)
		{	
			SetRect(&rect1,0,444,700,470);	
			InvalidateRect(hWnd,&rect1,true);
			x2=LOWORD(lParam);
			y2=HIWORD(lParam);
		}
		break;
		
	case WM_COMMAND:
		hMenu=GetMenu(hWnd);
		
		switch(LOWORD(wParam))
		{
		case ID_EXIT:
			if(sound==false)
			{
				PlaySound("Bye.wav",NULL,SND_FILENAME|SND_SYNC);
				PlaySound("exit.wav",NULL,SND_FILENAME|SND_SYNC);
			}	
			DestroyWindow(hWnd);
			break;
			
		case ID_BEGIN:
			SendMessage(hWnd,WM_KEYDOWN,VK_RETURN,lParam);
			break;
			
		case ID_PAUSE:
			SendMessage(hWnd,WM_KEYDOWN,VK_PAUSE,lParam);
			break;
			
		case ID_ABOUT:
			if(sound==false) {PlaySound(0,0,SND_PURGE);PlaySound("Hop.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);}
			DialogBox(hInst, (LPCTSTR)IDD_DIALOG1, hWnd, (DLGPROC)About);
			return 0;
			break;
			
		case ID_FLASH:
			if(sound==false){PlaySound(0,0,SND_PURGE);PlaySound("Yeahbaby.wav",NULL,SND_FILENAME|SND_ASYNC);}
			DialogBox(hInst, (LPCTSTR)IDD_DIALOG2, hWnd, (DLGPROC)About);
			return 0;
			break;
			
		case ID_RULES:
			if(sound==false){PlaySound(0,0,SND_PURGE);PlaySound("Hop.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);}
			DialogBox(hInst, (LPCTSTR)IDD_DIALOG3, hWnd, (DLGPROC)About);
			break;
			
		case ID_ballcolor:
			g=true;
			ChooseColor (&cc);
			if(cc.rgbResult!=RGB(128,128,128))
			{
				ball_color=cc.rgbResult;
				if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
				if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			}
			InvalidateRect(hWnd,NULL,true);
			g=false;
			break;
			
		case ID_kubColor:
			g=true;
			ChooseColor (&cc);
			if(cc.rgbResult!=RGB(128,128,128))
			{
				kubik_color=cc.rgbResult;
				if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
				if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			}
			InvalidateRect(hWnd,NULL,true);
			g=false;
			break;
			
		case ID_deskColor:
			g=true;
			ChooseColor (&cc);
			if(cc.rgbResult!=RGB(128,128,128))
			{
				desk_color=cc.rgbResult;
				if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
				if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			}
			InvalidateRect(hWnd,NULL,true);
			g=false;
			break;
			
		case ID_VERYSLOWLY:
			if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			speed=700000;
			CheckMenuItem(hMenu,iSelection,MF_UNCHECKED);
			iSelection=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection,MF_CHECKED);
			break;
			
		case ID_SLOW:
			if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			speed=300000;
			CheckMenuItem(hMenu,iSelection,MF_UNCHECKED);
			iSelection=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection,MF_CHECKED);
			break;
			
		case ID_NORM:
			if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			speed=70000;
			CheckMenuItem(hMenu,iSelection,MF_UNCHECKED);
			iSelection=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection,MF_CHECKED);
			break;
			
		case ID_FAST:
			if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			speed=5000;
			CheckMenuItem(hMenu,iSelection,MF_UNCHECKED);
			iSelection=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection,MF_CHECKED);
			break;
			
		case ID_VERYFAST:
			if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC);
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			speed=1;
			CheckMenuItem(hMenu,iSelection,MF_UNCHECKED);
			iSelection=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection,MF_CHECKED);
			break;
			
		case ID_KEYBOARD:
			if(sound==false)PlaySound("Stupid.wav",NULL,SND_FILENAME|SND_SYNC); 
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);
			klava=true;	
			CheckMenuItem(hMenu,iSelection1,MF_UNCHECKED);
			iSelection1=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection1,MF_CHECKED);	
			break;
			
		case ID_MOUSE:
			if(sound==false)PlaySound("pp.wav",NULL,SND_FILENAME|SND_SYNC); 
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);
			klava=false;
			CheckMenuItem(hMenu,iSelection1,MF_UNCHECKED);
			iSelection1=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection1,MF_CHECKED);
			break;
			
		case ID_SOUND:
			if(choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);
			sound=false;
			CheckMenuItem(hMenu,iSelection2,MF_UNCHECKED);
			iSelection2=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection2,MF_CHECKED);
			break;
			
		case ID_NOSOUND:
			PlaySound(0,NULL,SND_FILENAME|SND_ASYNC);
			sound=true;
			CheckMenuItem(hMenu,iSelection2,MF_UNCHECKED);
			iSelection2=LOWORD(wParam);
			CheckMenuItem(hMenu,iSelection2,MF_CHECKED);
			break;
			}
			
	case WM_PAINT:	// ������������ ����
		
		if(risovanie==true)
		{
			hdc = BeginPaint(hWnd, &ps);	// ������ ����������� �����
			hIcon=LoadIcon(hInst,LPCTSTR(IDI_ICON3));
			if(lives!=0)
				DrawIcon(hdc,10,10,hIcon);
			if(lives==2)
				DrawIcon(hdc,50,10,hIcon);
			SetRect(&rect,x-1,y-1,x+11,y+11);
			SelectObject(hdc,ball_brush);
			if (x2>622) x2=622;
			if (x2<21)  x2=21;
			if(mouse_click==false) Ellipse(hdc,x2+30,445,x2+40,455);
			else Ellipse(hdc,x,y,x+10,y+10);
			SelectObject(hdc,desk_brush);
			RoundRect(hdc,x2-20,455,x2+70,470,15,15);
			cout=round;
			if(cout==0)
			{
				itoa(cout,A,10);
				SetTextColor(hdc,RGB(200,0,0));
				SetBkColor(hdc,TRANSPARENT);
				TextOut(hdc,650,20,A,1);
			}
			if(cout==2700 || cout==5400)
			{ 
				SetTextColor(hdc,RGB(200,0,0));
				TextOut(hdc,650,20,A,4);
			}
			
			for(i=0;i<3;i++)
			{
				if(i==0){xk=100;yk=100;}
				if(i==1){xk=100;yk=121;}
				if(i==2){xk=100;yk=142;}
				
				for(j=0;j<9;j++)
				{
					if(mass[i][j]==0)
					{
						cout=cout+100;
						itoa(cout,A,10);
						if(cout>900)kol=4;else kol=3;
						SetTextColor(hdc,RGB(200,0,0));
						SetBkColor(hdc,TRANSPARENT);
						TextOut(hdc,650,20,A,kol);
						if((cout==2700 && round==0) || (cout==4100 && round==1400) || cout==6200){if(sound==false)PlaySound("excelent.wav",NULL,SND_FILENAME|SND_SYNC);yb=490;}
					}
					
					if(mass[i][j]==1)
					{
						SelectObject(hdc,kubik_brush);
						Rectangle(hdc,xk,yk,xk+55,yk+20);
					}
					
					xk=xk+56;
				}
			}
			
			if(x>=92 && x<=603 && y>=92 && y<=162)
			{
				if(y==120 || y==141 || y==162)
				{	
					i=(y-100)/21;
					j=(x-100)/56;
					
					if(x<=590)
					{
						ii=(y-100)/21;
						jj=(x+10-100)/56;
					}
					
					if(mass[i][j]==1 || mass[ii][jj]==1)
					{
						mass[i][j]=0;
						SetRect(&rect2,100+56*j,100+21*i,100+56*j+56,100+20*i+21);
						InvalidateRect(hWnd,&rect2,true);
						if(x<=590)
						{
							mass[ii][jj]=0;
							SetRect(&rect2,100+56*jj,100+21*ii,100+56*jj+56,100+20*ii+21);
							InvalidateRect(hWnd,&rect2,true);
						}
						if(sound==false)PlaySound("Kubik.wav",NULL,SND_FILENAME|SND_ASYNC);
						SetRect(&rect3,650,20,700,40);
						InvalidateRect(hWnd,&rect3,true);
						
						switch (stena)
						{
						case (1):
							ugol=3.14-ugol;
							radius=2;
							break;
							
						case (2):
							ugol=3*3.14/2-ugol;
							radius=2;
							break;
							
						case (3):
							radius=radius+1;
							break;
							
						case (4):
							ugol=3.14/2-ugol;
							radius=2;
							break; 
						}
						
						y=100+21*i+21;
						stena=3;
						xb=x;
						yb=y;
					}
					
				}
				
				
				if((x==92 || x==148 || x==204 || x==260 || x==316 || x== 372 || x==428 || x==484 || x==540) && (y!=162 && y!=141 && y!=120 && y!=92 && y!=113 && y!=134)) 
				{ 
					j=(x+10-100)/56;
					i=(y-100)/21;
					
					jj=(x+10-100)/56;
					ii=(y+10-100)/21;
					
					if(mass[i][j]==1 || mass[ii][jj]==1)
					{
						mass[i][j]=0;mass[ii][jj]=0;
						if(sound==false)PlaySound("Kubik.wav",NULL,SND_FILENAME|SND_ASYNC);
						SetRect(&rect2,100+56*j,100+21*i,100+56*j+56,100+20*i+21);
						InvalidateRect(hWnd,&rect2,true);
						SetRect(&rect2,100+56*jj,100+21*ii,100+56*jj+56,100+20*ii+21);
						InvalidateRect(hWnd,&rect2,true);
						SetRect(&rect3,650,20,700,40);
						InvalidateRect(hWnd,&rect3,true);
						
						switch (stena)
						{
						case (1):
							ugol=3.14/2-ugol;
							radius=2;
							break;
							
						case (2):
							ugol=3.14-ugol;
							radius=2;
							break;
							
						case (3):
							ugol=3*3.14/2-ugol;
							radius=2;
							break;
							
						case (4):
							radius=radius+1;
							break;
						}
						x=100+56*j-9;
						stena=4;
						xb=x;
						yb=y;
						
					}
				}
				
				if((x==155 || x==211 || x==267 || x==323 || x==379 || x==435 || x==491 || x==547 || x==603) && (y!=162 && y!=141 && y!=120 && y!=92 && y!=113 && y!=134)) 
				{ 
					j=(x-100)/56;
					i=(y-100)/21;
					
					jj=(x-100)/56;
					ii=(y+10-100)/21;
					
					if(mass[i][j]==1 || mass[ii][jj]==1)
					{
						mass[i][j]=0;mass[ii][jj]=0;
						if(sound==false)PlaySound("Kubik.wav",NULL,SND_FILENAME|SND_ASYNC);
						SetRect(&rect2,100+56*j,100+21*i,100+56*j+56,100+20*i+21);
						InvalidateRect(hWnd,&rect2,true);
						SetRect(&rect2,100+56*jj,100+21*ii,100+56*jj+56,100+20*ii+21);
						InvalidateRect(hWnd,&rect2,true);
						SetRect(&rect3,650,20,700,40);
						InvalidateRect(hWnd,&rect3,true);
						
						switch (stena)
						{
						case (1):
							ugol=3*3.14/2-ugol;
							radius=2;
							break;
							
						case (2):
							radius=radius+1;
							break;
							
						case (3):
							ugol=3.14/2-ugol;
							radius=2;
							break;
							
						case (4):
							ugol=3.14-ugol;
							radius=2;
							break;
						}
						x=100+56*j+56;	
						stena=2;
						xb=x;
						yb=y;
						
					}
				}
				
				if(y==92 || y==113 || y==134)
				{
					i=(y+10-100)/21;
					j=(x-100)/56;
					
					if(x<=590)
					{
						ii=(y+10-100)/21;
						jj=(x+10-100)/56;
					}
					
					if(mass[i][j]==1 || mass[ii][jj]==1)
					{
						mass[i][j]=0; 
						SetRect(&rect2,100+56*j,100+21*i,100+56*j+56,100+20*i+21);
						InvalidateRect(hWnd,&rect2,true);
						if(x<=590)
						{
							mass[ii][jj]=0;
							SetRect(&rect2,100+56*jj,100+21*ii,100+56*jj+56,100+20*ii+21);
							InvalidateRect(hWnd,&rect2,true);
						}
						if(sound==false)PlaySound("Kubik.wav",NULL,SND_FILENAME|SND_ASYNC);
						SetRect(&rect3,650,20,700,40);
						InvalidateRect(hWnd,&rect3,true);
						
						switch (stena)
						{
						case (1):
							radius=radius+1;
							break;
							
						case (2):
							ugol=3.14/2-ugol;
							radius=2;
							break;
							
						case (3):
							ugol=3.14-ugol;
							radius=2;
							break;
							
						case (4):
							ugol=3*3.14/2-ugol;
							radius=2;
							break;
						}
						y=100+21*i-9;
						stena=1;
						xb=x;
						yb=y;
					}
				}
				
				
			}				    
			
			
			if(y<500)InvalidateRect(hWnd,&rect,true);
			
			if(polet==true)
			{		     	
				switch (stena)
				{
				case (1):
					x=xb+(radius*cos(ugol));
					y=yb-(radius*sin(ugol));
					break;
					
				case (2):
					x=xb+(radius*sin(ugol));
					y=yb+(radius*cos(ugol));
					break;
					
				case (3):
					x=floor(xb-(radius*cos(ugol)));
					y=yb+(radius*sin(ugol));
					break;
					
				case (4):
					x=xb-(radius*sin(ugol));
					y=yb-(radius*cos(ugol));
					break;
				}
				
				for(j=0;j<speed;j++)
				{
				}
				radius=radius+1;
				
				if (y>=445 && y<450)
				{
					if(x>=x2-30 && x<=x2+70)
					{    
						if(sound==false)PlaySound("Doska.wav",NULL,SND_FILENAME|SND_ASYNC);
						z=x-x2+20-1;
						c=z/45;
						ugol=3.14159/2*(2-c);
						radius=2;
						if(ugol<3.14159/6 ) ugol=3.14159/6;
						if(ugol>5*3.14159/6) ugol=5*3.14159/6;
						
						y=445;
						stena=1;
						xb=x;
						yb=y;
						
					}
					else InvalidateRect(hWnd,NULL,true);
				}
				
				if(y>=470)
				{
					risovanie=false;
					
					if(cout!=2700 && cout!=4100)
					{
						if(lives==0)
						{
							for(i=0;i<3;i++)
							{
								for(j=0;j<9;j++)
								{
									mass[i][j]=1;
								}
							}
							if(sound==false)PlaySound("gameover.wav",NULL,SND_FILENAME|SND_ASYNC);
							choiceText=3;
							lives=2;
							round=0;
						}
						else 
						{
							lives--;
							if(sound==false)PlaySound("gameover.wav",NULL,SND_FILENAME|SND_ASYNC);
							choiceText=7;
						}
						yb=0;
					}
					if(cout==6200)
					{
						for(i=0;i<3;i++)
						{
							for(j=0;j<9;j++)
							{
								mass[i][j]=1;
							}
						}
						if(sound==false)
						{
							PlaySound("Congrat.wav",NULL,SND_FILENAME|SND_SYNC);
							PlaySound("Applauds.wav",NULL,SND_FILENAME|SND_ASYNC);
						}
						choiceText=4;round=0;yb=0;lives=2;
					}
					
					InvalidateRect(hWnd,NULL,true);
					
					if(cout==2700)
					{
						choiceText=5;
						for(i=0;i<3;i++)
						{
							for(j=0;j<9;j++)
							{
								if((i==0 || i==2)  && j%2==0 )
									mass[i][j]=1;
								if(i==1 && j%2!=0)
									mass[i][j]=1;
							}
						}
						round=1400;
						yb=0;
					}
					
					if(cout==4100)
					{
						choiceText=5;
						for(i=0;i<3;i++)
						{
							for(j=0;j<9;j++)
							{
								if(i==0 || i==2)
								{
									if(j==4) mass[i][j]=0; 
									else mass[i][j]=1;
								}
								if(i==1)
								{
									if(j==1||j==2||j==6||j==7)mass[i][j]=0;
									else mass[i][j]=1;
								}
							}
						}
						round=3500;
						yb=0;
					}
					mouse_click=false;i=0;
					text_right=700;
					text_left=-70;
					y=50;
					polet=false;
				}
				
				if (y<=5)
				{
					if(sound==false && mouse_click==true)
						PlaySound("Stena.wav",NULL,SND_FILENAME|SND_ASYNC); 
					
					switch (stena)
					{
					case (1):
						ugol=3.14-ugol;
						radius=2;
						break;
						
					case (2):
						ugol=3*3.14/2-ugol;
						radius=2;
						break;
						
					case (3):
						radius=radius+1;
						break;
						
					case (4):
						ugol=3.14/2-ugol;
						radius=2;
						break; 
					}
					y=5;
					stena=3;
					xb=x;
					yb=y;
					if(ugol<3.14/100) ugol=3.14/100;
				}
				
				if (x<=0)
				{
					if(sound==false && mouse_click==true)
						PlaySound("Stena.wav",NULL,SND_FILENAME|SND_ASYNC); 
					
					switch (stena)
					{
					case (1):
						ugol=3*3.14/2-ugol;
						radius=2;
						break;
						
					case (2):
						radius=radius+1;
						break;
						
					case (3):
						ugol=3.14/2-ugol;
						radius=2;
						break;
						
					case (4):
						ugol=3.14-ugol;
						radius=2;
						break;
					}
					x=0;
					stena=2;
					xb=x;
					yb=y;
					if(ugol<3.14/100) ugol=3.14/100;
				}
				
				if (x>=685)
				{
					if(sound==false && mouse_click==true)
						PlaySound("Stena.wav",NULL,SND_FILENAME|SND_ASYNC);
					
					switch (stena)
					{
					case (1):
						ugol=3.14/2-ugol;
						radius=2;
						break;
						
					case (2):
						ugol=3.14-ugol;
						radius=2;
						break;
						
					case (3):
						ugol=3*3.14/2-ugol;
						radius=2;
						break;
						
					case (4):
						radius=radius+1;
						break;
					}
					x=685;
					stena=4;
					xb=x;
					yb=y;
					if(ugol<3.14/100) ugol=3.14/100;
				}
				
	}
	EndPaint(hWnd, &ps);	// ��������� ����������� �����
	}
	break;
	
	case WM_DESTROY:			// ���������� ������
		PostQuitMessage(0);
		DeleteObject(ball_brush);
		DeleteObject(kubik_brush);
		DeleteObject(desk_brush);
		break;
		
	default: 
		// ��������� ���������, ������� �� ���������� ����������-
		// ���
		return DefWindowProc(hWnd, message, wParam, lParam); 
    }
	return 0;		
	
}


LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		{
			PlaySound(0,NULL,SND_FILENAME|SND_ASYNC);
			if(sound==false && choiceText==1)PlaySound("play.wav",NULL,SND_FILENAME|SND_ASYNC|SND_LOOP);	
			EndDialog(hDlg, LOWORD(wParam));
			return 0;
		}
		break;
	}
    return 0;
}

