// KP.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								
TCHAR szTitle[MAX_LOADSTRING];								
TCHAR szWindowClass[MAX_LOADSTRING];								
// Foward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
HBRUSH Br1,Old1,Br2,Old2,Br3,Old3,Br4,Old4;
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;
	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_KK, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);
	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}
	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_KK);
	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return msg.wParam;
}
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage is only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_KK);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCSTR)IDC_KK;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);
	return RegisterClassEx(&wcex);
}
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }
   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);
   return TRUE;
}
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	TCHAR szHello[MAX_LOADSTRING];
	LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
	static int x[400]={0,10,10,20,20,30,30,40},y[400]={10,0,10,0,10,0,10,0},i,cx[400],cy[400];
	static int p=0,c=0,k=0,m=0;
    static int ax1=90,ay1=20,ax2=100,ay2=10;
	static int n=4; 
	static int w=0,b=0; 
	static int xsize,ysize;
	static int octx,octy,octw,octx1,octy1; 
	static int Stx[10]={30,80,100,320,570,70,610,200,230,400},Sty[10]={20,30,410,360,80,150,160,200,250,100};
	static int r=0;
	POINT Point[1];
		Point[0].x=(rand()%800);
		Point[0].y=(rand()%800);
	     switch (message) 
	{
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			switch (wmId)
			{
				case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
				case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
				default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			}
			break;
		case WM_SIZE:
            xsize=LOWORD(lParam);
		    ysize=HIWORD(lParam);
			break;
		case WM_PAINT: 
			char dd[3];
			hdc = BeginPaint(hWnd, &ps);
			RECT rt;
			GetClientRect(hWnd, &rt);
			for(i=0;i<n;i++)
			{   
				Br1=CreateSolidBrush(RGB(0,255,0));
				Old1=(HBRUSH)SelectObject(hdc,Br1);
				Rectangle(hdc,x[2*i],y[2*i],x[2*i+1],y[2*i+1]);
				SelectObject(hdc,Old1);
				DeleteObject(Br1);
			}
			if(x[2*n-1]>xsize||x[2*n-2]<0||y[2*n-1]<0||y[2*n-2]>ysize)
			{    	n=4;m=0;c=0;p=0;k=0;w=0;
					x[0]=0;x[1]=10;x[2]=10;x[3]=20;x[4]=20;x[5]=30;x[6]=30;x[7]=40;
                    y[0]=10;y[1]=0;y[2]=10;y[3]=0;y[4]=10;y[5]=0;y[6]=10;y[7]=0;
			}
			if(ay1==0)
			{
            ay1=10;
            ay2=0;
			}
			if(ax1==xsize)
			{
			ax1=xsize-10;
			ax2=xsize;
			}
            for(i=0;i<n-2;i++)
			{
				if(x[2*i]==x[2*n-2]&&y[2*i]==y[2*n-2]&&x[2*i+1]==x[2*n-1]&&y[2*i+1]==y[2*n-1])
				{
					n=4;m=0;c=0;p=0;k=0;w=0;
					x[0]=0;x[1]=10;x[2]=10;x[3]=20;x[4]=20;x[5]=30;x[6]=30;x[7]=40;
                    y[0]=10;y[1]=0;y[2]=10;y[3]=0;y[4]=10;y[5]=0;y[6]=10;y[7]=0;
				}
			}
                if(x[2*n-1]==ax2&&x[2*n-2]==ax1&&y[2*n-1]==ay2&&y[2*n-2]==ay1)
				{
					n=n+1;
					x[2*n-1]=ax2;
					x[2*n-2]=ax1;
					y[2*n-1]=ay2;
					y[2*n-2]=ay1;
				}
                if(x[2*n-1]==ax2&&y[2*n-1]==ay2&&x[2*n-2]==ax1&&y[2*n-2]==ay1)
				{
				w=w+1;
                octw=w%20; 
				if(Point[0].x>xsize)
				 {
	        	   Point[0].x=xsize-10;
				 }
		         if(Point[0].y>ysize)
				 {
		           Point[0].y=ysize-10;
				 }
				 octx=Point[0].x%10;
				 octy=Point[0].y%10;
				 Point[0].x=Point[0].x-octx;
				 Point[0].y=Point[0].y-octy;
					ax1=Point[0].x;
					ay1=Point[0].y;
				 	ax2=ax1+10;
					ay2=ay1-10;
				}
				if(octw==0&&w>1)
				{
				r=1;
				}
				if(w>200)
				{
				w=w-1;
				}
				if(r==1)
				{
				for(i=0;i<w/20;i++)
				{
			    Br3=CreateSolidBrush(RGB(0,0,255));
				Old3=(HBRUSH)SelectObject(hdc,Br3);
				Rectangle(hdc,Stx[i],Sty[i],Stx[i]+50,Sty[i]-10);
				SelectObject(hdc,Old3);
				DeleteObject(Br3);
                }
				} 
				for(i=0;i<w/20;i++)
				{
                if(x[2*n-2]>=Stx[i]&&x[2*n-2]<Stx[i]+50&&y[2*n-2]==Sty[i])
				{
                    n=4;m=0;c=0;p=0;k=0;w=0;
					x[0]=0;x[1]=10;x[2]=10;x[3]=20;x[4]=20;x[5]=30;x[6]=30;x[7]=40;
                    y[0]=10;y[1]=0;y[2]=10;y[3]=0;y[4]=10;y[5]=0;y[6]=10;y[7]=0;
				}
                }
				for(i=0;i<w/20;i++)
				{
                if(ax1>=Stx[i]&&ax1<Stx[i]+50&&ay1==Sty[i])
				{
                ax1=600; 
				ay1=20;
				ax2=610;
				ay2=10;
				}
				}
				Br2=CreateSolidBrush(RGB(0,255,0));
				Old2=(HBRUSH)SelectObject(hdc,Br2);
				Rectangle(hdc,ax1,ay1,ax2,ay2);
				SelectObject(hdc,Old2);
				DeleteObject(Br2);
                
				itoa(w,dd,10);
				TextOut(hdc,250,0,dd,3);
			EndPaint(hWnd, &ps);
			break;
		case WM_CREATE:
			SetTimer(hWnd,NULL,100,NULL);
			break;
		case WM_TIMER:
			for(i=0;i<2*n;i++)
			{
				cx[i]=x[i];
			    cy[i]=y[i];
			}
            if(c==1) 
			{
			    x[2*n-1]=x[2*n-1]+10;
		    	x[2*n-2]=x[2*n-2]+10;
			for(i=0;i<2*n-2;i++)
			{
                x[i]=cx[i+2];
			    y[i]=cy[i+2];
			}
			}
			if(p==1) 
			{
			    y[2*n-1]=y[2*n-1]+10;
		    	y[2*n-2]=y[2*n-2]+10;
            for(i=0;i<2*n-2;i++)
			{
                x[i]=cx[i+2];
			    y[i]=cy[i+2];
			}
			} 
            if(k==1) 
			{
			    y[2*n-1]=y[2*n-1]-10;
		    	y[2*n-2]=y[2*n-2]-10;
            for(i=0;i<2*n-2;i++)
			{
                x[i]=cx[i+2];
			    y[i]=cy[i+2];
			}
			} 
			if(m==1) 
			{
			    x[2*n-1]=x[2*n-1]-10;
		    	x[2*n-2]=x[2*n-2]-10;
            for(i=0;i<2*n-2;i++)
			{
                x[i]=cx[i+2];
			    y[i]=cy[i+2];
			}
			} 
			
			InvalidateRect(hWnd,NULL,TRUE);
			break;
		case WM_KEYDOWN:
			switch(wParam)
			{
			case VK_DOWN:
				p=1;c=0;k=0;m=0;
			break;
			case VK_RIGHT:
				c=1;p=0;k=0;m=0;
			break;
			case VK_UP:
                k=1;c=0;p=0;m=0;
			break;
			case VK_LEFT:
				m=1;c=0;p=0;k=0;
				break;
			case VK_DELETE:
				m=0;c=0;p=0;k=0;
            break;
			}
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

// Mesage handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
			break;
	}
    return FALSE;
}
